# MKTG6205A course website

Quarto source for **MKTG6205A: Contemporary Topics in Behavioural Marketing**, Term 1 2026–27.

## Render locally

```bash
quarto render
```

The generated static site is written to `docs/`. GitHub Pages can serve that directory or the included workflow can publish it with GitHub Actions.

Reading PDFs and student information are intentionally excluded. The Course Slides are the only PDF included in the site.
